<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CourseFeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
